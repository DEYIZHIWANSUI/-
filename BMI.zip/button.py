import pygame
pygame.init()
canvas = pygame.display.set_mode((960,650))
bg = pygame.image.load(r"C:\Users\MECHREV\Pictures\Uplay\比利海灵顿.jpg")
canvas.blit(bg,(0,0))
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    pygame.display.update()