import pygame
from pygame.locals import *
def canva():
    global canvas,bg
    pygame.init()
    canvas = pygame.display.set_mode((480, 648))
    canvas.fill((255, 255, 255))
    pygame.display.set_caption('查看图片')
    bg = pygame.image.load(r'C:\Users\MECHREV\Pictures\编程\项目\体重6.jpg')


def handleEvent():
    for event in pygame.event.get():
        if event.type == MOUSEMOTION:
            print('x坐标为' + str(event.pos[0]))
            print('y坐标为' + str(event.pos[1]))


while True:
    canva()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    canvas.blit(bg, (0, 0))
    # 刷新屏幕
    pygame.display.update()
    # 延迟处理
    pygame.time.delay(15)
    handleEvent()
