#请在下方书写你的代码
import easygui
h = easygui.enterbox('请输入身高(米)',title='健康顾问')
with open('height.txt','w',encoding='utf-8') as f:
    f.write(h)
