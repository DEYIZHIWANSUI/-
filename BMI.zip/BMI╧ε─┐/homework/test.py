#一码当先代码文件
import easygui

#请在下方书写你的代码
#题目：创建enterbox输入框，提示信息：请输入你最爱的动漫
#     将用户输入的数据存储在action变量中
#     使用with open方法，将action变量保存在action.txt文档中


