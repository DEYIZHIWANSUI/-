import pygame
from sys import exit
from subprocess import Popen,PIPE
import os

# pygame初始化
pygame.init()
canvas = pygame.display.set_mode((1050, 660))
pygame.display.set_caption('健康顾问')
path = "images/bg1.png"
bg = pygame.image.load(path)
canvas.blit(bg, (0, 0))
weight = []

def result():
    path = "images/bg2.png" 
    bg = pygame.image.load(path)
    canvas.blit(bg, (0, 0))
    #请在下方完成你的代码
    os.system('python diagram.py %s %s' %(height,','.join(weight)))
    temTrend = pygame.image.load('images/trend.png')
    canvas.blit(temTrend,(455,105))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
        # 判断鼠标是否按下
        if event.type == pygame.MOUSEBUTTONDOWN:
            # 判断是否是鼠标左键被按下
            if event.button == 1:
                # 获取鼠标坐标位置
                pos = pygame.mouse.get_pos()
                mouseX = pos[0]
                mouseY = pos[1]
                if 585 <= mouseX <= 815 and 240 <= mouseY <= 320:
                    #请在下方完成你的代码
                    p = Popen('python enterbox1.py',shell=True,stdout=PIPE)
                    print(p.stdout.readline())
                    with open('height.txt',encoding='utf-8') as f:
                        height = f.read()
                        print(height)

                if 585 <= mouseX <= 815 and 355 <= mouseY <= 433:
                    p = Popen('python enterbox2.py',shell=True,stdout=PIPE)
                    print(p.stdout.readline())
                    with open('weight.txt',encoding='utf-8') as f:
                        weight.append(f.read())
                        print(weight)
                        
                if 585 <= mouseX <= 815 and 470 <= mouseY <= 545:
                    result()
    pygame.display.update()



