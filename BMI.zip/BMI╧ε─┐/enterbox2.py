import easygui
w = easygui.enterbox('请输入体重(千克)',title='健康顾问')
with open('weight.txt','w',encoding='utf-8') as f:
    f.write(w)
