import sys
import matplotlib.pyplot as plt
import platform

def plot():
    # 绘图
    plt.figure(figsize=(5.5, 4))
    # 可以绘制出bmh的风格
    plt.style.use('bmh')  
    # 用来正常显示中文标签
    if platform.system() == 'Windows':
        plt.rcParams['font.sans-serif'] = 'SimHei'  
    else:
        plt.rcParams['font.sans-serif'] = 'Arial Unicode MS'
    # 用来正常显示负号
    plt.rcParams['axes.unicode_minus'] = False 
    #请在下方完成你的代码 
    plt.xticks(size=13)
    plt.yticks(size=13)
    plt.xlabel('体重(kg)',size=15)
    plt.ylabel('指数(%)', size=15)
    plt.plot(weight,number)
    plt.legend(labels=['体重指数'])
    plt.savefig('images/trend.png')


#请在下方完成你的代码
height = float(sys.argv[1])
print(height)
w = sys.argv[2]
print(w)
weight = w.split(',')
print(weight)
number = []
for i in weight:
    number.append(float(i)/(height * height))
plot()
