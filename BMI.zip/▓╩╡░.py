import easygui,pygame
easygui.msgbox('万圣节快乐!')
def showResult():
    pygame.init()
    global canvas
    pygame.font.init()
    pygame.display.set_caption("彩蛋")
    canvas = pygame.display.set_mode((512, 288))
    bg = pygame.image.load(r"I:\编程\项目\万圣节.jpg")
    canvas.blit(bg,(0,0))
def font():
    TextFont = pygame.font.SysFont('SimHei', 20)
    wenzi = TextFont.render('谢宇宸，奉上', True, (255, 255, 255))
    canvas.blit(wenzi,(380,262))
while True:
    showResult()
    font()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    pygame.display.update()
