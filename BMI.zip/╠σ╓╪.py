import easygui,pygame,sys,os
import tkinter as tk
from tkinter import *
from tkinter import filedialog,messagebox
from PIL import Image,ImageTk
print('''
____  ___.___________________.___.____ ____________   ___ ______________ _______   
\   \/  /|   \_   _____/\__  |   |    |   \_   ___ \ /   |   \_   _____/ \      \  
 \     / |   ||    __)_  /   |   |    |   /    \  \//    ~    \    __)_  /   |   \ 
 /     \ |   ||        \ \____   |    |  /\     \___\    Y    /        \/    |    *
/___/\  \|___/_______  / / ______|______/  \______  /\___|_  /_______  /\____|__  /
      \_/            \/  \/                       \/       \/        \/         \/ 
      ''')

window = tk.Tk()
window.resizable(0, 0)
window.title('BMI检测')


# Button按钮
def label():
    global bg, choose, tizhong,shengao
    bg = ImageTk.PhotoImage(Image.open(r"I:\编程\项目\体重5.jpg"))
    bgLabel = tk.Label(window,
                       width = 366,
                       height = 496,
                       image = bg,

                       )
    bgLabel.pack()
    choose = ImageTk.PhotoImage(Image.open(r'I:\编程\项目\BMI值3.jpg'))
    chooseBtn = tk.Button(window,
                          image = choose,
                          bd = 0,
                          width = 320,
                          height = 35,
                          command = Bmi
                          )
    chooseBtn.place(x=30, y=220)
    tizhong = ImageTk.PhotoImage(Image.open( r'I:\编程\项目\space button.jpg'))
    tizhongBtn = tk.Button(window,
                           image=tizhong,
                           bd=0,
                           width=320,
                           height=35,
                           command=showbutton)
    tizhongBtn.place(x=30, y=164)
    shengao = ImageTk.PhotoImage(Image.open(r'I:\编程\项目\space button2.jpg'))
    shengaoBtn = tk.Button(window,
                           image=shengao,
                           bd=0,
                           width=320,
                           height=35,
                           command=showbutton2)
    shengaoBtn.place(x = 30,y = 100)

def showbutton():
    global tizhong
    tizhong = easygui.enterbox('请输入体重(单位kg)', title='bmi指数')
    with open('tizhong.txt', 'w', encoding='utf-8') as f:
        f.write(tizhong)

def showbutton2():
    global shengao
    shengao = easygui.enterbox('请输入身高(单位cm):', title='bmi指数')
    with open('shengao.txt','w',encoding='utf-8') as s:
        s.write(shengao)
def Bmi():
    global zhi,gender
    gender = easygui.enterbox('请输入性别(如‘男’‘女’)填错按男生计算', title='bmi指数')
    with open('female.txt', 'w', encoding='utf-8') as e:
        e.write(gender)
    bmi2()
    if gender == '男':
        if 16.5 <= float(bmi) <= 23.2:
            easygui.msgbox('您的体重正常，单项得分为100')
            zhi= '您的体重正常，单项得分为100'
        elif float(bmi) <= 16.4 and float(bmi) != 0:
            easygui.msgbox('您的体重等级为低体重，单项得分为80')
            zhi = '您的体重等级为低体重，单项得分为80'
        elif  23.3 <= float(bmi) <=26.3:
            easygui.msgbox('您的体重超重，单项得分为80')
            zhi = '您的体重超重，单项得分为80'
        elif float(bmi) >= 26.4:
            easygui.msgbox('您已肥胖，单项得分为60')
            zhi = '您已肥胖，单项得分为60'
        elif float(bmi) == 0:
            messagebox.showwarning(title='恭喜',
                                       message='您触发彩蛋')
            zhi = '0'
    elif gender == '女':
        if 16.5 <= float(bmi) <= 22.7:
            easygui.msgbox('您的体重正常，单项得分为100')
            zhi = '您的体重正常，单项得分为100'
        elif float(bmi) <= 16.4 and float(bmi) != 0:
            easygui.msgbox('您的体重等级为低体重，单项得分为80')
            zhi = '您的体重等级为低体重，单项得分为80'
        elif 22.8 <= float(bmi) <= 25.2:
            easygui.msgbox('您的体重超重，单项得分为80')
            zhi = '您的体重超重，单项得分为80'
        elif float(bmi) >= 25.3:
            easygui.msgbox('您已肥胖，单项得分为60')
            zhi = '您已肥胖，单项得分为60'
        elif float(bmi) == 0:
            messagebox.showwarning(title='恭喜',
                                       message='您触发彩蛋')
            zhi = '0'
    else:
        easygui.msgbox('请正确输入性别，人妖除外~')
        zhi = '请正确输入性别，人妖除外~'

    with open('bmi3.txt', 'w', encoding='utf-8') as f:
        f.write(zhi)

    caidan()
    os.system('start canva.py')
    exit()
def bmi2():
    global bmi,zhi
    if tizhong.isdigit():
        if shengao.isdigit():
            bmI = float(tizhong) / ((float(shengao)/100) ** 2)
            bmi = '%.2f' % bmI
        else:
            messagebox.showwarning(title='注意！',
                                   message='请正确输入身高')
            exit()
    else:
        messagebox.showwarning(title='注意！',
                               message='请正确输入体重')
        exit()

    with open('bmi.txt','w',encoding='utf-8') as b:
        b.write(str(bmi))

def caidan():
    if zhi == '0':
        os.system('start 彩蛋.py')
        exit()
while True:
    label()
    Button(window, text="Quit", command=quit).pack()
    # 刷新
    window.mainloop()

