import easygui,pygame,sys,os,requests
from tkinter import *
from pygame.locals import QUIT
with open('bmi3.txt', 'r', encoding='utf-8') as f:
    zhi = f.read()
with open('bmi.txt', 'r', encoding='utf-8') as m:
    bmi = m.read()
    bmi2 = 'BMI:'+ bmi
with open('female.txt','r',encoding='utf-8') as e:
    female = e.read()
with open('tizhong.txt','r',encoding='utf-8') as t:
    tizhong = t.read()
with open('shengao.txt','r',encoding='utf-8') as s:
    shengao = s.read()
def showResult():
    pygame.init()
    global canvas
    pygame.font.init()
    pygame.display.set_caption("BMI检测")
    canvas = pygame.display.set_mode((366, 496))
    bg = pygame.image.load(r"I:\编程\项目\体重6.jpg")
    canvas.blit(bg,(0,0))
def font():
    global wenzi,bmi3,female2,shengao2,tizhong2,xinbie
    TextFont = pygame.font.SysFont('SimHei',20)
    TextFont2 = pygame.font.SysFont('SimHei',15)
    wenzi = TextFont2.render(zhi,True,(255,255,255))
    bmi3 = TextFont.render(bmi2,True,(255,255,255))
    female2 = TextFont.render(female,True,(255,255,255))
    shengao2 = TextFont.render(shengao,True,(0,0,0))
    tizhong2 = TextFont.render(tizhong,True,(0,0,0))
    xinbie = TextFont2.render('身高(cm)', True, (255, 255, 255))

def canva():
    canvas.blit(shengao2, (30,103))
    canvas.blit(tizhong2, (30, 173))
    canvas.blit(female2, (30, 281))
    canvas.blit(bmi3,(72,281))
    canvas.blit(wenzi,(27,261))
    canvas.blit(xinbie,(24,78))



while True:
    showResult()
    font()
    canva()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    pygame.display.update()
